package lab2;

import java.util.HashMap;
import java.util.Map;

public class StatisticsUtils 
{

	protected static double calculateFeatureAverage(Double[] feature) {
		Map<Double, Integer> counterMap = getFeatureDistincElementsCounterMap(feature);
		double featureAverage = 0;

		double sum1 = 0;
		double sum2 = 0;

		sum1 = counterMap.keySet().stream()
				.mapToDouble(x -> calculateSum1(x, counterMap.get(x))).sum();
		sum2 = counterMap.values().stream()
				.mapToInt(x -> x).sum();
		featureAverage = sum1 / sum2;
		System.out.println("The feature average is: " +  featureAverage);
		return featureAverage;
}
	
	protected static Map<Double, Integer> getFeatureDistincElementsCounterMap(Double feature[])
	{
		Map<Double, Integer> counterMap = new HashMap<Double, Integer>();
		for (int j = 0; j < feature.length; j++) {
			if (counterMap.containsKey(feature[j])) {
				int count = counterMap.get(feature[j]);
				counterMap.put((feature[j]), ++count);
			} else {
				counterMap.put((feature[j]), 1);
			}
		}
		return counterMap;
	}
	
	private static Double calculateSum1(double value, int count)
	{
		return count * value;
	}

	protected static double calculateFeatureWeightedAverage(Double[] feature, Double[] weights) {
		Map<Double, Double> weightMap = getFeatureDistinctElementsWeightMap(feature, weights);

		double sum1 = 0;
		double sum2 = 0;
		
		sum1 = weightMap.keySet().stream().mapToDouble(x -> calculateSum2(x, weightMap.get(x))).sum();
		sum2 = weightMap.keySet().stream().mapToDouble(x -> x ).sum();
		
		return sum1/sum2;
	}
	
	private static Double calculateSum2(double value, double sumWeight)
	{
		return sumWeight * value;
	}
	
	private static Map<Double, Double> getFeatureDistinctElementsWeightMap(Double[] feature, Double[] weights) {
		Map<Double, Double> counterMap = new HashMap<Double, Double>();
		for (int j = 0; j < feature.length; j++) {
			if (counterMap.containsKey(feature[j])) {
				double weight = counterMap.get(feature[j]);
				counterMap.put((feature[j]), weight + weights[j]);
			} else {
				counterMap.put((feature[j]), weights[j]);
			}
		}
		return counterMap;
	}

	protected static double calculateFrequencyOfOccurence(Map<Double, Integer> counterMap, double featureElement) {
		double frequencyOfOccurence = 0.0;

		double sum2 = counterMap.keySet().stream().mapToDouble(x -> x ).sum();
		return counterMap.get(featureElement) / sum2;
	}
	
	protected static double calculateFeatureDispersion(Double[] feature, double featureWeightedAverage) {
		double featureDispersion = 0.0;
		// your code here
		return featureDispersion;
	}
	
	protected static double calculateCovariance (Double[] feature1, Double[] feature2,
			double feature1WeightedAverage,double feature2WeightedAverage) {
		double covariance = 0.0;
		// your code here
		return covariance;
	}
	
	protected static double calculateCorrelationCoefficient  (double covariance, double feature1Dispersion, 
			double feature2Dispersion ) {
		double correlationCoefficient = 0.0;
		// your code here
		return correlationCoefficient;
	}
	
	protected static double calculateAverageSquareDeviation (double featureDispersion ) {
		double averageSquareDeviation = 0.0;
		// your code here
		return averageSquareDeviation;
	}
}
